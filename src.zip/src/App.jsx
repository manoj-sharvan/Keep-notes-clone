import React from "react";
import { useEffect } from "react";
import Header from "./components/Header";
import { useState } from "react";
import "./App.css";
import NoteForm from "./components/NoteForm";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import NoteList from "./components/NoteList";
import EditModel from "./components/EditModel";

const INITIAL_NOTES = [
  {
    id: 1,
    title: "CURD",
    content: "CREATE, UPDATE, READ, DELETE",
    color: "#fff8b8",
  },
];

const App = () => {
  const [notes, setNotes] = useState(() => {
    try {
      const saved = localStorage.getItem("notes_app");
      return saved && JSON.parse(saved)?.length !== 0
        ? JSON.parse(saved)
        : INITIAL_NOTES;
    } catch {
      return INITIAL_NOTES;
    }
  });

  const [searchQuery, setSearchQuery] = useState("");
  const [editingNote, setEditingNote] = useState(null);

  useEffect(() => {
    localStorage.setItem("notes_app", JSON.stringify(notes));
  }, [notes]);

  const handleAddNote = (newNoteData) => {
    const newNote = {
      id: Date.now(),
      title: newNoteData.title,
      content: newNoteData.content,
      color: "#fff8b8",
    };
    setNotes((prev) => [newNote, ...prev]);
  };

  const handleUpdateNote = (id, updatedFields) => {
    setNotes((prevNotes) =>
      prevNotes.map((note) =>
        note.id === id ? { ...note, ...updatedFields } : note,
      ),
    );
    toast.info("Note get updated");
  };

  const handleDeleteNote = (note) => {
    const id = note.id;
    setNotes((prevNotes) => prevNotes.filter((note) => note.id !== id));
    toast.warn("Note gets Deleted");
  };

  console.log(Boolean(editingNote), editingNote, "editingNote");

  return (
    <div className="app">
      <ToastContainer position="top-right" />

      <Header searchQuery={searchQuery} setSearchQuery={setSearchQuery} />

      <main className="main-container">
        {/* CREATE (C) */}
        <NoteForm />
        {/*READ (R) */}
        <NoteList
          notes={notes}
          onEdit={(note) => setEditingNote(note)}
          onDelete={handleDeleteNote}
        />

        <EditModel
          isOpen={Boolean(editingNote)}
          note={editingNote}
          onClose={() => setEditingNote(null)}
          onSave={handleUpdateNote}
        />
      </main>
    </div>
  );
};

export default App;
