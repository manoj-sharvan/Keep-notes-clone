import React from "react";
import NoteCard from "./NoteCard";
import { useSelector } from "react-redux";
import { getAllNotes } from "../store/notesSlice";

const NoteList = ({ notes, onEdit, onDelete }) => {
  const notes_reducer = useSelector(getAllNotes);
  console.log(notes_reducer, "notes_reducer");
  return (
    <div className="notes-grid">
      {notes_reducer.map((note) => {
        return (
          <NoteCard
            key={note.id}
            note={note}
            onEdit={onEdit}
            onDelete={onDelete}
          />
        );
      })}
    </div>
  );
};

export default NoteList;
